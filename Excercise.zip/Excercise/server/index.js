const express = require('express');
const mongoose = require('mongoose');
const app = express();

const studnetModel = require ("./models/student");
app.use(express.json());
mongoose.connect('mongodb+srv://newuser:12345@cluster0.wepco.mongodb.net/student?retryWrites=true&w=majority',{
    useNewUrlParser: true,
});

app.get('/', async (req,res)=>{
    const student = new studnetModel({ firstName: "Subham", lastName: "Patra", emailId: "patrasubham834@gmail.com", phoneNumber: 7008073528})
    try{
        await student.save();
        res.send("Inserted data");
    }
    catch(err){
        console.log(err)
    }
});
app.listen(3001, ()=>
{
    console.log("Server is runing on port 3001");
})