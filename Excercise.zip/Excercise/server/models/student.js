const mongoose = require('mongoose')

const studentSchema = new mongoose.Schema({
    firstName:{
        type: String,
        required: true,
    },
    lastName:{
        type: String,
        required: true,
    },
    emailId:{
        type: String,
        required: true,
    },
    phoneNumber:{
        type: Number,
        required: true,
    },
})

const student = mongoose.model("student",studentSchema);
module.exports = student;